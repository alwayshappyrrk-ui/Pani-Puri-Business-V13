Pani Puri Business V13
Offline-first billing app with local storage, Google Drive backup/restore via Android document picker, Excel export, dashboard, customers, menu management, reminders and Admin PIN. Supabase email login is removed from the main app flow.

Google Drive note: Backup uses Android ACTION_CREATE_DOCUMENT / ACTION_OPEN_DOCUMENT, so when Google Drive is available as a storage location you can save/restore the JSON backup there without embedding Google service credentials in the APK.
