package com.panipuri.business;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.annotation.NonNull;
import androidx.webkit.WebViewAssetLoader;

import android.window.OnBackInvokedCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_DRIVE_CREATE = 7001;
    private static final int REQ_DRIVE_OPEN = 7002;
    private final OnBackInvokedCallback backCallback = this::handleBackPressed;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        // Enable JavaScript alert()/confirm() dialogs used by Delete/Clear actions.
        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                WebResourceResponse r = loader.shouldInterceptRequest(Uri.parse(url));
                return r != null ? r : super.shouldInterceptRequest(view, url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                WebResourceResponse r = loader.shouldInterceptRequest(request.getUrl());
                return r != null ? r : super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });

        webView.addJavascriptInterface(new AndroidXlsxBridge(), "AndroidXlsx");
        webView.addJavascriptInterface(new AndroidDriveBridge(), "AndroidDrive");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        setContentView(webView);

        // Android 13+ uses the system Back gesture / predictive Back callback.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }



    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < 33) {
            handleBackPressed();
        }
    }

    private void handleBackPressed() {
        if (webView == null) {
            finish();
            return;
        }
        webView.evaluateJavascript(
                "(window.PPHandleBack ? window.PPHandleBack() : false)",
                value -> {
                    if ("true".equals(value)) return;
                    finish();
                });
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public class AndroidDriveBridge {
        @JavascriptInterface
        public void backup(final String json, final String requestedName) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, sanitizeName(requestedName));
                    pendingDriveBackup = json == null ? "{}" : json;
                    startActivityForResult(i, REQ_DRIVE_CREATE);
                } catch (Exception e) {
                    driveCallback("__driveBackupResult", false, e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void restore() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                    startActivityForResult(i, REQ_DRIVE_OPEN);
                } catch (Exception e) {
                    driveCallback("__driveRestoreResult", false, e.getMessage());
                }
            });
        }
    }

    private String pendingDriveBackup;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_DRIVE_CREATE) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                pendingDriveBackup = null;
                driveCallback("__driveBackupResult", false, "Backup cancel केला");
                return;
            }
            try {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("File open failed");
                    out.write((pendingDriveBackup == null ? "{}" : pendingDriveBackup).getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingDriveBackup = null;
                driveCallback("__driveBackupResult", true, null);
            } catch (Exception e) {
                pendingDriveBackup = null;
                driveCallback("__driveBackupResult", false, e.getMessage());
            }
        } else if (requestCode == REQ_DRIVE_OPEN) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                driveCallback("__driveRestoreResult", false, "Restore cancel केला");
                return;
            }
            try {
                Uri uri = data.getData();
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("File open failed");
                String content = readAll(in);
                in.close();
                JSONObject r = new JSONObject().put("ok", true).put("content", content);
                final String raw = r.toString();
                runOnUiThread(() -> webView.evaluateJavascript("window.__driveRestoreResult(" + JSONObject.quote(raw) + ");", null));
            } catch (Exception e) {
                driveCallback("__driveRestoreResult", false, e.getMessage());
            }
        }
    }

    private void driveCallback(String fn, boolean ok, String error) {
        try {
            JSONObject r = new JSONObject().put("ok", ok);
            if (error != null) r.put("error", error);
            String raw = r.toString();
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("window." + fn + "(" + JSONObject.quote(raw) + ");", null); });
        } catch (Exception ignored) {}
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) b.append(line); }
        return b.toString();
    }

    public class AndroidXlsxBridge {
        @JavascriptInterface
        public void export(final String jsonRows, final String requestedName) {
            new Thread(() -> {
                try {
                    JSONArray rows = new JSONArray(jsonRows);
                    String name = sanitizeName(requestedName);
                    if (!name.toLowerCase(Locale.US).endsWith(".xlsx")) name += ".xlsx";
                    byte[] xlsx = buildXlsx(rows);
                    saveToDownloads(name, xlsx);
                    runOnUiThread(() -> webView.evaluateJavascript(
                            "window.__xlsxSaved=true;", null));
                } catch (Exception e) {
                    runOnUiThread(() -> webView.evaluateJavascript(
                            "window.__xlsxError=" + jsQuote(e.getMessage()) + ";", null));
                }
            }).start();
        }
    }

    private void saveToDownloads(String name, byte[] data) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            values.put(MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/Pani Puri Business");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Downloads folder access failed");
            try (OutputStream out = cr.openOutputStream(uri)) {
                if (out == null) throw new Exception("Could not open download stream");
                out.write(data);
            }
            values.clear();
            values.put(MediaStore.Downloads.IS_PENDING, 0);
            cr.update(uri, values, null, null);
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/Pani Puri Business");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("Downloads folder could not be created");
            File f = new File(dir, name);
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
        }
    }

    private byte[] buildXlsx(JSONArray rows) throws Exception {
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        ZipOutputStream zip = new ZipOutputStream(baos);
        add(zip, "[Content_Types].xml", contentTypes());
        add(zip, "_rels/.rels", rels());
        add(zip, "xl/workbook.xml", workbook());
        add(zip, "xl/_rels/workbook.xml.rels", workbookRels());
        add(zip, "xl/styles.xml", styles());
        add(zip, "xl/worksheets/sheet1.xml", sheet(rows));
        zip.finish();
        zip.close();
        return baos.toByteArray();
    }

    private void add(ZipOutputStream zip, String path, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>";
    }

    private String rels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>";
    }

    private String workbook() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Sales\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
    }

    private String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "</Relationships>";
    }

    private String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><name val=\"Arial\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
                "</styleSheet>";
    }

    private String sheet(JSONArray rows) throws Exception {
        int rowCount = rows.length();
        int maxCols = 0;
        for (int i = 0; i < rowCount; i++) maxCols = Math.max(maxCols, rows.optJSONArray(i) != null ? rows.getJSONArray(i).length() : 0);
        String lastCol = colName(Math.max(1, maxCols));
        StringBuilder x = new StringBuilder();
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        x.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        x.append("<dimension ref=\"A1:").append(lastCol).append(rowCount).append("\"/>");
        x.append("<sheetViews><sheetView workbookViewId=\"0\"/></sheetViews>");
        x.append("<sheetData>");
        for (int r = 0; r < rowCount; r++) {
            JSONArray row = rows.optJSONArray(r);
            if (row == null) continue;
            x.append("<row r=\"").append(r + 1).append("\">");
            for (int c = 0; c < row.length(); c++) {
                String ref = colName(c + 1) + (r + 1);
                String v = row.isNull(c) ? "" : String.valueOf(row.get(c));
                x.append("<c r=\"").append(ref).append("\" t=\"inlineStr\" s=\"").append(r == 0 ? 1 : 0).append("\"><is><t xml:space=\"preserve\">")
                        .append(xml(v)).append("</t></is></c>");
            }
            x.append("</row>");
        }
        x.append("</sheetData></worksheet>");
        return x.toString();
    }

    private String colName(int n) {
        StringBuilder s = new StringBuilder();
        while (n > 0) { int rem = (n - 1) % 26; s.insert(0, (char)('A' + rem)); n = (n - 1) / 26; }
        return s.toString();
    }

    private String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    private String sanitizeName(String n) {
        if (n == null || n.trim().isEmpty()) n = "PaniPuri_Sales.xlsx";
        return n.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private String jsQuote(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\"";
    }
}
